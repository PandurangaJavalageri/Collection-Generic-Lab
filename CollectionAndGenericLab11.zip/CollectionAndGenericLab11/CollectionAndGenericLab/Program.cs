﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionAndGenericLab
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();
            bool acceptFlag = false;
            while (!acceptFlag)
            {
                Console.WriteLine("Enter some integer");
                int i = int.Parse(Console.ReadLine()); Console.WriteLine("Do you want to continue? Y/N");
                string accept = Console.ReadLine().ToUpper();
                list.Add(i);

                if (accept =="Y")
{
                    acceptFlag = false;
                }
else
                {
                    acceptFlag = true;
                }
            }
            Console.WriteLine($"No of integers in the list{list.Count}");
            Console.WriteLine($"avg of all integers values{list.Average()}");
            int mid;
            if(list.Count%2== 0)
            {
                mid=list.Count/2;
                mid++;
            }
            else
            {
                mid=list.Count/2;
            }
            int aver=(int)list.Average();
            list.Insert(mid,(int) list.Average());
            display(list);

            list.Remove(list[1]);
            display(list);
            for (int i= 0;i<list.Count;i++)
            {
                if (list[i] ==aver)
                {
                    list.RemoveAt(i);
                }
            }
           

            display(list);
            Console.WriteLine("Remove method removes the specified element in list");
            Console.WriteLine("Removeat remove the element specified at particular index");



        }
        public static void display(List<int> list)
        {
            foreach (int i in list)
                Console.Write(i + " ");
            Console.WriteLine();
        }
       
    }
}
