﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionAndGeneric2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ClsPerson clsPerson1 = new ClsPerson();
            clsPerson1.Name = "Test1";

            ClsPerson clsPerson2 = new ClsPerson();
            clsPerson2.Name = "Test2";
            ClsPerson clsPerson3 = new ClsPerson();
            clsPerson3.Name = "Test3";
            List<ClsPerson> clsList = new List<ClsPerson>();
            clsList.Add(clsPerson1);
            clsList.Add(clsPerson2);
            clsList.Add(clsPerson3);
            foreach (ClsPerson clsPerson in clsList)
            {
                Console.WriteLine(clsPerson.Name);
            }
            Console.WriteLine("we can traverse it in 5 ways");
            

        }
    }
    public class ClsPerson
    {
        public string Name { get; set; }
    }
}
