﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionAndGenericLab14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Queue<string> queue = new Queue<string>();
            queue.Enqueue("string1");
            queue.Enqueue("string2");
            queue.Enqueue("string4");
            queue.Enqueue("string5");
            List<string> list = queue.ToList();
            foreach (var item in queue)
            {
                Console.WriteLine(item);
            }
            list.Insert(2, "string3");
          
            for (int i = 0; i < list.Count; i++)
            {
                queue.Enqueue(list[i]);
                if(i!=list.Count-1)
                queue.Dequeue();
            }
            foreach (var item in queue)
            {
                Console.WriteLine(item);
            }



        }
    }

}
