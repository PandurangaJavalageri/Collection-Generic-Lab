﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionAndGenericLab13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack<string> stack = new Stack<string>();
            stack.Push("string1");
            stack.Push("string2");
            stack.Push("string4");
            stack.Push("string5");
            foreach (var item in stack)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("string5 since it follows fifo principle");
            stack.Pop();
            stack.Pop();
            stack.Push("string3");
            stack.Push("string4");
            stack.Push("string5");
            Console.WriteLine(stack.Peek());

        }
    }
}
