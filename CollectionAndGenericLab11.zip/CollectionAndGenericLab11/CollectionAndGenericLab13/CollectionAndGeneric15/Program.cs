﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionAndGeneric15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Hashtable ht = new Hashtable();
            ClsPerson clsPerson1 = new ClsPerson{ Name="test",Age=18};
            
            ClsPerson clsPerson2 = new ClsPerson { Name = "test1", Age = 20 };
          
            ClsPerson clsPerson3 = new ClsPerson { Name = "test2", Age = 17 };
            
            ht.Add(clsPerson1.Name, clsPerson1);
            ht.Add(clsPerson2.Name, clsPerson2);
            ht.Add(clsPerson3.Name, clsPerson3);
            Console.WriteLine("we can add jyothi to the table");
            ClsPerson clsPerson4 = new ClsPerson { Name = "Jyothi" };
            ht.Add(clsPerson4.Name,clsPerson4 );
            Console.WriteLine("we can add a person with name jyothi");
            Console.WriteLine("we cannot add a person with age 10");
            Console.WriteLine();
            SortedList<string, ClsPerson> s1 = new SortedList<string, ClsPerson>();

            foreach (var key in ht.Keys)
            {
                 
                Console.WriteLine(key);
                if (((ClsPerson)ht[key]).CanVote()==true)
                {
                    Console.WriteLine(key+"can vote");
                }
                else
                {
                    Console.WriteLine(key+"cannot vote");
                }
                
                s1.Add((string)key, (ClsPerson)ht[key]);
                
            }
            Console.WriteLine();
            Console.WriteLine();
            foreach (var k in s1)
            {
                Console.WriteLine(k.Key);
                var obj = k.Value;
                if (obj.CanVote() == true)
                {
                    Console.WriteLine(obj.Name + "can vote");
                }
                else
                {
                    Console.WriteLine(obj.Name + "cannot vote");
                }

            }
            Console.WriteLine("key value pairs are displayed in sortedlist are in sorted order");




        }
        public class ClsPerson
        {
            public ClsPerson()
            {

            }
            public string Name { get; set; }
            public int Age { get; set; }
            public string PlaceOfBirth { get; set; }
            public bool CanVote()
            {
                if (Age >= 18)
                {
                    return true;
                }
                else
                { return false; }
            }
        }

    }

}
